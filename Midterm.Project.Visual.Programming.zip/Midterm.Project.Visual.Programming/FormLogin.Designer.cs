﻿namespace Midterm.Project.Visual.Programming
{
    partial class FormLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormLogin));
            this.tabLogin = new System.Windows.Forms.TabControl();
            this.pageCustomer = new System.Windows.Forms.TabPage();
            this.btnCancelCust = new System.Windows.Forms.Button();
            this.btnDeleteCust = new System.Windows.Forms.Button();
            this.txtNameCust = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.checkCustom = new System.Windows.Forms.CheckBox();
            this.txtPasswordCust = new System.Windows.Forms.TextBox();
            this.txtSurnameCust = new System.Windows.Forms.TextBox();
            this.lblPasswordCust = new System.Windows.Forms.Label();
            this.lblUserSurnameCust = new System.Windows.Forms.Label();
            this.btnLoginCust = new System.Windows.Forms.Button();
            this.lblLogoCust = new System.Windows.Forms.Label();
            this.picLogoCust = new System.Windows.Forms.PictureBox();
            this.pageManufacturer = new System.Windows.Forms.TabPage();
            this.btnCancelMan = new System.Windows.Forms.Button();
            this.btnDeleteMan = new System.Windows.Forms.Button();
            this.txtSurnameMan = new System.Windows.Forms.TextBox();
            this.lblUserSurnameMan = new System.Windows.Forms.Label();
            this.checkMan = new System.Windows.Forms.CheckBox();
            this.txtPasswordMan = new System.Windows.Forms.TextBox();
            this.txtNameMan = new System.Windows.Forms.TextBox();
            this.lblPasswordMan = new System.Windows.Forms.Label();
            this.lblUserNameMan = new System.Windows.Forms.Label();
            this.btnLoginMan = new System.Windows.Forms.Button();
            this.lblLogoMan = new System.Windows.Forms.Label();
            this.picLogoMan = new System.Windows.Forms.PictureBox();
            this.tabLogin.SuspendLayout();
            this.pageCustomer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picLogoCust)).BeginInit();
            this.pageManufacturer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picLogoMan)).BeginInit();
            this.SuspendLayout();
            // 
            // tabLogin
            // 
            this.tabLogin.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tabLogin.Controls.Add(this.pageCustomer);
            this.tabLogin.Controls.Add(this.pageManufacturer);
            this.tabLogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.tabLogin.Location = new System.Drawing.Point(153, 65);
            this.tabLogin.Name = "tabLogin";
            this.tabLogin.SelectedIndex = 0;
            this.tabLogin.Size = new System.Drawing.Size(498, 387);
            this.tabLogin.TabIndex = 0;
            // 
            // pageCustomer
            // 
            this.pageCustomer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.pageCustomer.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pageCustomer.Controls.Add(this.btnCancelCust);
            this.pageCustomer.Controls.Add(this.btnDeleteCust);
            this.pageCustomer.Controls.Add(this.txtNameCust);
            this.pageCustomer.Controls.Add(this.label1);
            this.pageCustomer.Controls.Add(this.checkCustom);
            this.pageCustomer.Controls.Add(this.txtPasswordCust);
            this.pageCustomer.Controls.Add(this.txtSurnameCust);
            this.pageCustomer.Controls.Add(this.lblPasswordCust);
            this.pageCustomer.Controls.Add(this.lblUserSurnameCust);
            this.pageCustomer.Controls.Add(this.btnLoginCust);
            this.pageCustomer.Controls.Add(this.lblLogoCust);
            this.pageCustomer.Controls.Add(this.picLogoCust);
            this.pageCustomer.ForeColor = System.Drawing.Color.Black;
            this.pageCustomer.Location = new System.Drawing.Point(4, 25);
            this.pageCustomer.Name = "pageCustomer";
            this.pageCustomer.Padding = new System.Windows.Forms.Padding(3);
            this.pageCustomer.Size = new System.Drawing.Size(490, 358);
            this.pageCustomer.TabIndex = 0;
            this.pageCustomer.Text = "Customer Login";
            this.pageCustomer.Click += new System.EventHandler(this.pageCustomer_Click);
            // 
            // btnCancelCust
            // 
            this.btnCancelCust.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnCancelCust.BackColor = System.Drawing.Color.White;
            this.btnCancelCust.ForeColor = System.Drawing.Color.Navy;
            this.btnCancelCust.Location = new System.Drawing.Point(306, 297);
            this.btnCancelCust.Name = "btnCancelCust";
            this.btnCancelCust.Size = new System.Drawing.Size(89, 34);
            this.btnCancelCust.TabIndex = 7;
            this.btnCancelCust.Text = "Cancel";
            this.btnCancelCust.UseVisualStyleBackColor = false;
            this.btnCancelCust.Click += new System.EventHandler(this.btnCancelCust_Click);
            // 
            // btnDeleteCust
            // 
            this.btnDeleteCust.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnDeleteCust.BackColor = System.Drawing.Color.White;
            this.btnDeleteCust.ForeColor = System.Drawing.Color.Navy;
            this.btnDeleteCust.Location = new System.Drawing.Point(211, 297);
            this.btnDeleteCust.Name = "btnDeleteCust";
            this.btnDeleteCust.Size = new System.Drawing.Size(89, 34);
            this.btnDeleteCust.TabIndex = 6;
            this.btnDeleteCust.Text = "Delete";
            this.btnDeleteCust.UseVisualStyleBackColor = false;
            this.btnDeleteCust.Click += new System.EventHandler(this.btnDeleteCust_Click);
            // 
            // txtNameCust
            // 
            this.txtNameCust.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtNameCust.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtNameCust.Location = new System.Drawing.Point(209, 179);
            this.txtNameCust.Name = "txtNameCust";
            this.txtNameCust.Size = new System.Drawing.Size(167, 20);
            this.txtNameCust.TabIndex = 1;
            this.txtNameCust.TextChanged += new System.EventHandler(this.txtNameCust_TextChanged);
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.DarkBlue;
            this.label1.Location = new System.Drawing.Point(115, 179);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "User Name";
            // 
            // checkCustom
            // 
            this.checkCustom.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.checkCustom.AutoSize = true;
            this.checkCustom.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.checkCustom.Location = new System.Drawing.Point(274, 257);
            this.checkCustom.Name = "checkCustom";
            this.checkCustom.Size = new System.Drawing.Size(102, 17);
            this.checkCustom.TabIndex = 4;
            this.checkCustom.Text = "Show Password";
            this.checkCustom.UseVisualStyleBackColor = true;
            this.checkCustom.CheckedChanged += new System.EventHandler(this.checkCustom_CheckedChanged);
            // 
            // txtPasswordCust
            // 
            this.txtPasswordCust.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtPasswordCust.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtPasswordCust.Location = new System.Drawing.Point(209, 231);
            this.txtPasswordCust.Name = "txtPasswordCust";
            this.txtPasswordCust.PasswordChar = '*';
            this.txtPasswordCust.Size = new System.Drawing.Size(167, 20);
            this.txtPasswordCust.TabIndex = 3;
            this.txtPasswordCust.TextChanged += new System.EventHandler(this.txtPasswordCust_TextChanged);
            // 
            // txtSurnameCust
            // 
            this.txtSurnameCust.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtSurnameCust.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtSurnameCust.Location = new System.Drawing.Point(209, 205);
            this.txtSurnameCust.Name = "txtSurnameCust";
            this.txtSurnameCust.Size = new System.Drawing.Size(167, 20);
            this.txtSurnameCust.TabIndex = 2;
            this.txtSurnameCust.TextChanged += new System.EventHandler(this.txtSurnameCust_TextChanged);
            // 
            // lblPasswordCust
            // 
            this.lblPasswordCust.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblPasswordCust.AutoSize = true;
            this.lblPasswordCust.ForeColor = System.Drawing.Color.Navy;
            this.lblPasswordCust.Location = new System.Drawing.Point(126, 231);
            this.lblPasswordCust.Name = "lblPasswordCust";
            this.lblPasswordCust.Size = new System.Drawing.Size(77, 17);
            this.lblPasswordCust.TabIndex = 0;
            this.lblPasswordCust.Text = "Password";
            this.lblPasswordCust.Click += new System.EventHandler(this.lblPasswordCust_Click);
            // 
            // lblUserSurnameCust
            // 
            this.lblUserSurnameCust.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblUserSurnameCust.AutoSize = true;
            this.lblUserSurnameCust.ForeColor = System.Drawing.Color.DarkBlue;
            this.lblUserSurnameCust.Location = new System.Drawing.Point(92, 205);
            this.lblUserSurnameCust.Name = "lblUserSurnameCust";
            this.lblUserSurnameCust.Size = new System.Drawing.Size(111, 17);
            this.lblUserSurnameCust.TabIndex = 0;
            this.lblUserSurnameCust.Text = "User Surname";
            this.lblUserSurnameCust.Click += new System.EventHandler(this.lblUserNameCust_Click);
            // 
            // btnLoginCust
            // 
            this.btnLoginCust.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnLoginCust.BackColor = System.Drawing.Color.White;
            this.btnLoginCust.ForeColor = System.Drawing.Color.Navy;
            this.btnLoginCust.Location = new System.Drawing.Point(116, 297);
            this.btnLoginCust.Name = "btnLoginCust";
            this.btnLoginCust.Size = new System.Drawing.Size(89, 34);
            this.btnLoginCust.TabIndex = 5;
            this.btnLoginCust.Text = "Login";
            this.btnLoginCust.UseVisualStyleBackColor = false;
            this.btnLoginCust.Click += new System.EventHandler(this.btnLoginCust_Click);
            // 
            // lblLogoCust
            // 
            this.lblLogoCust.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblLogoCust.AutoSize = true;
            this.lblLogoCust.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblLogoCust.ForeColor = System.Drawing.Color.DarkBlue;
            this.lblLogoCust.Location = new System.Drawing.Point(154, 121);
            this.lblLogoCust.Name = "lblLogoCust";
            this.lblLogoCust.Size = new System.Drawing.Size(207, 24);
            this.lblLogoCust.TabIndex = 0;
            this.lblLogoCust.Text = "Stock Control System";
            this.lblLogoCust.Click += new System.EventHandler(this.lblLogoCust_Click);
            // 
            // picLogoCust
            // 
            this.picLogoCust.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.picLogoCust.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.picLogoCust.Image = ((System.Drawing.Image)(resources.GetObject("picLogoCust.Image")));
            this.picLogoCust.Location = new System.Drawing.Point(209, 28);
            this.picLogoCust.Name = "picLogoCust";
            this.picLogoCust.Size = new System.Drawing.Size(89, 81);
            this.picLogoCust.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picLogoCust.TabIndex = 7;
            this.picLogoCust.TabStop = false;
            this.picLogoCust.Click += new System.EventHandler(this.picLogoCust_Click);
            // 
            // pageManufacturer
            // 
            this.pageManufacturer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.pageManufacturer.Controls.Add(this.btnCancelMan);
            this.pageManufacturer.Controls.Add(this.btnDeleteMan);
            this.pageManufacturer.Controls.Add(this.txtSurnameMan);
            this.pageManufacturer.Controls.Add(this.lblUserSurnameMan);
            this.pageManufacturer.Controls.Add(this.checkMan);
            this.pageManufacturer.Controls.Add(this.txtPasswordMan);
            this.pageManufacturer.Controls.Add(this.txtNameMan);
            this.pageManufacturer.Controls.Add(this.lblPasswordMan);
            this.pageManufacturer.Controls.Add(this.lblUserNameMan);
            this.pageManufacturer.Controls.Add(this.btnLoginMan);
            this.pageManufacturer.Controls.Add(this.lblLogoMan);
            this.pageManufacturer.Controls.Add(this.picLogoMan);
            this.pageManufacturer.Location = new System.Drawing.Point(4, 25);
            this.pageManufacturer.Name = "pageManufacturer";
            this.pageManufacturer.Padding = new System.Windows.Forms.Padding(3);
            this.pageManufacturer.Size = new System.Drawing.Size(490, 358);
            this.pageManufacturer.TabIndex = 1;
            this.pageManufacturer.Text = "Manufacturer Login";
            this.pageManufacturer.Click += new System.EventHandler(this.pageManufacturer_Click);
            // 
            // btnCancelMan
            // 
            this.btnCancelMan.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnCancelMan.BackColor = System.Drawing.Color.White;
            this.btnCancelMan.ForeColor = System.Drawing.Color.Navy;
            this.btnCancelMan.Location = new System.Drawing.Point(306, 295);
            this.btnCancelMan.Name = "btnCancelMan";
            this.btnCancelMan.Size = new System.Drawing.Size(89, 34);
            this.btnCancelMan.TabIndex = 7;
            this.btnCancelMan.Text = "Cancel";
            this.btnCancelMan.UseVisualStyleBackColor = false;
            this.btnCancelMan.Click += new System.EventHandler(this.btnCancelMan_Click);
            // 
            // btnDeleteMan
            // 
            this.btnDeleteMan.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnDeleteMan.BackColor = System.Drawing.Color.White;
            this.btnDeleteMan.ForeColor = System.Drawing.Color.Navy;
            this.btnDeleteMan.Location = new System.Drawing.Point(211, 295);
            this.btnDeleteMan.Name = "btnDeleteMan";
            this.btnDeleteMan.Size = new System.Drawing.Size(89, 34);
            this.btnDeleteMan.TabIndex = 6;
            this.btnDeleteMan.Text = "Delete";
            this.btnDeleteMan.UseVisualStyleBackColor = false;
            this.btnDeleteMan.Click += new System.EventHandler(this.btnDeleteMan_Click);
            // 
            // txtSurnameMan
            // 
            this.txtSurnameMan.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtSurnameMan.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtSurnameMan.Location = new System.Drawing.Point(209, 203);
            this.txtSurnameMan.Name = "txtSurnameMan";
            this.txtSurnameMan.Size = new System.Drawing.Size(167, 20);
            this.txtSurnameMan.TabIndex = 2;
            this.txtSurnameMan.TextChanged += new System.EventHandler(this.txtSurnameMan_TextChanged);
            // 
            // lblUserSurnameMan
            // 
            this.lblUserSurnameMan.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblUserSurnameMan.AutoSize = true;
            this.lblUserSurnameMan.ForeColor = System.Drawing.Color.DarkBlue;
            this.lblUserSurnameMan.Location = new System.Drawing.Point(92, 203);
            this.lblUserSurnameMan.Name = "lblUserSurnameMan";
            this.lblUserSurnameMan.Size = new System.Drawing.Size(111, 17);
            this.lblUserSurnameMan.TabIndex = 0;
            this.lblUserSurnameMan.Text = "User Surname";
            // 
            // checkMan
            // 
            this.checkMan.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.checkMan.AutoSize = true;
            this.checkMan.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.checkMan.Location = new System.Drawing.Point(274, 258);
            this.checkMan.Name = "checkMan";
            this.checkMan.Size = new System.Drawing.Size(102, 17);
            this.checkMan.TabIndex = 4;
            this.checkMan.Text = "Show Password";
            this.checkMan.UseVisualStyleBackColor = true;
            this.checkMan.CheckedChanged += new System.EventHandler(this.checkMan_CheckedChanged);
            // 
            // txtPasswordMan
            // 
            this.txtPasswordMan.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtPasswordMan.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtPasswordMan.Location = new System.Drawing.Point(209, 229);
            this.txtPasswordMan.Name = "txtPasswordMan";
            this.txtPasswordMan.PasswordChar = '*';
            this.txtPasswordMan.Size = new System.Drawing.Size(167, 20);
            this.txtPasswordMan.TabIndex = 3;
            this.txtPasswordMan.TextChanged += new System.EventHandler(this.txtPasswordMan_TextChanged);
            // 
            // txtNameMan
            // 
            this.txtNameMan.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtNameMan.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txtNameMan.Location = new System.Drawing.Point(209, 177);
            this.txtNameMan.Name = "txtNameMan";
            this.txtNameMan.Size = new System.Drawing.Size(167, 20);
            this.txtNameMan.TabIndex = 1;
            this.txtNameMan.TextChanged += new System.EventHandler(this.txtNameMan_TextChanged);
            // 
            // lblPasswordMan
            // 
            this.lblPasswordMan.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblPasswordMan.AutoSize = true;
            this.lblPasswordMan.ForeColor = System.Drawing.Color.Navy;
            this.lblPasswordMan.Location = new System.Drawing.Point(126, 229);
            this.lblPasswordMan.Name = "lblPasswordMan";
            this.lblPasswordMan.Size = new System.Drawing.Size(77, 17);
            this.lblPasswordMan.TabIndex = 0;
            this.lblPasswordMan.Text = "Password";
            this.lblPasswordMan.Click += new System.EventHandler(this.lblPasswordMan_Click);
            // 
            // lblUserNameMan
            // 
            this.lblUserNameMan.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblUserNameMan.AutoSize = true;
            this.lblUserNameMan.ForeColor = System.Drawing.Color.DarkBlue;
            this.lblUserNameMan.Location = new System.Drawing.Point(115, 178);
            this.lblUserNameMan.Name = "lblUserNameMan";
            this.lblUserNameMan.Size = new System.Drawing.Size(88, 17);
            this.lblUserNameMan.TabIndex = 0;
            this.lblUserNameMan.Text = "User Name";
            this.lblUserNameMan.Click += new System.EventHandler(this.lblUserNameMan_Click);
            // 
            // btnLoginMan
            // 
            this.btnLoginMan.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnLoginMan.BackColor = System.Drawing.Color.White;
            this.btnLoginMan.ForeColor = System.Drawing.Color.Navy;
            this.btnLoginMan.Location = new System.Drawing.Point(117, 295);
            this.btnLoginMan.Name = "btnLoginMan";
            this.btnLoginMan.Size = new System.Drawing.Size(89, 34);
            this.btnLoginMan.TabIndex = 5;
            this.btnLoginMan.Text = "Login ";
            this.btnLoginMan.UseVisualStyleBackColor = false;
            this.btnLoginMan.Click += new System.EventHandler(this.btnLoginMan_Click);
            // 
            // lblLogoMan
            // 
            this.lblLogoMan.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblLogoMan.AutoSize = true;
            this.lblLogoMan.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblLogoMan.ForeColor = System.Drawing.Color.DarkBlue;
            this.lblLogoMan.Location = new System.Drawing.Point(154, 119);
            this.lblLogoMan.Name = "lblLogoMan";
            this.lblLogoMan.Size = new System.Drawing.Size(207, 24);
            this.lblLogoMan.TabIndex = 0;
            this.lblLogoMan.Text = "Stock Control System";
            this.lblLogoMan.Click += new System.EventHandler(this.lblLogoMan_Click);
            // 
            // picLogoMan
            // 
            this.picLogoMan.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.picLogoMan.Image = ((System.Drawing.Image)(resources.GetObject("picLogoMan.Image")));
            this.picLogoMan.Location = new System.Drawing.Point(209, 26);
            this.picLogoMan.Name = "picLogoMan";
            this.picLogoMan.Size = new System.Drawing.Size(89, 81);
            this.picLogoMan.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picLogoMan.TabIndex = 0;
            this.picLogoMan.TabStop = false;
            this.picLogoMan.Click += new System.EventHandler(this.picLogoMan_Click);
            // 
            // FormLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.BackgroundImage = global::Midterm.Project.Visual.Programming.Properties.Resources.Ekran_görüntüsü_2023_04_12_174656;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(807, 534);
            this.Controls.Add(this.tabLogin);
            this.DoubleBuffered = true;
            this.Name = "FormLogin";
            this.Text = "Stock Control System Login";
            this.Load += new System.EventHandler(this.FormLogin_Load);
            this.tabLogin.ResumeLayout(false);
            this.pageCustomer.ResumeLayout(false);
            this.pageCustomer.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picLogoCust)).EndInit();
            this.pageManufacturer.ResumeLayout(false);
            this.pageManufacturer.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picLogoMan)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabLogin;
        private System.Windows.Forms.TabPage pageCustomer;
        private System.Windows.Forms.TabPage pageManufacturer;
        private System.Windows.Forms.Label lblLogoMan;
        private System.Windows.Forms.PictureBox picLogoMan;
        private System.Windows.Forms.TextBox txtPasswordMan;
        private System.Windows.Forms.TextBox txtNameMan;
        private System.Windows.Forms.Label lblPasswordMan;
        private System.Windows.Forms.Label lblUserNameMan;
        private System.Windows.Forms.Button btnLoginMan;
        private System.Windows.Forms.TextBox txtPasswordCust;
        private System.Windows.Forms.TextBox txtSurnameCust;
        private System.Windows.Forms.Label lblPasswordCust;
        private System.Windows.Forms.Label lblUserSurnameCust;
        private System.Windows.Forms.Button btnLoginCust;
        private System.Windows.Forms.Label lblLogoCust;
        private System.Windows.Forms.PictureBox picLogoCust;
        private System.Windows.Forms.CheckBox checkCustom;
        private System.Windows.Forms.CheckBox checkMan;
        private System.Windows.Forms.TextBox txtNameCust;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtSurnameMan;
        private System.Windows.Forms.Label lblUserSurnameMan;
        private System.Windows.Forms.Button btnCancelCust;
        private System.Windows.Forms.Button btnDeleteCust;
        private System.Windows.Forms.Button btnCancelMan;
        private System.Windows.Forms.Button btnDeleteMan;
    }
}