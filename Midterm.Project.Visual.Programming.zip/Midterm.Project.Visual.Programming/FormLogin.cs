﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Midterm.Project.Visual.Programming
{
    public partial class FormLogin : Form
    {
        Thread th;

        public static string userName;
        public static string userSurname;
        public static string userPassword;
        public FormLogin()
        {
            InitializeComponent();
        }

        private void FormLogin_Load(object sender, EventArgs e)
        {

        }

        private void pageCustomer_Click(object sender, EventArgs e)
        {

        }

        private void pageManufacturer_Click(object sender, EventArgs e)
        {

        }


        private void picLogoCust_Click(object sender, EventArgs e)
        {

        }

        private void picLogoMan_Click(object sender, EventArgs e)
        {

        }


        private void lblLogoCust_Click(object sender, EventArgs e)
        {

        }

        private void lblLogoMan_Click(object sender, EventArgs e)
        {

        }

        private void lblUserNameCust_Click(object sender, EventArgs e)
        {

        }

        private void lblUserNameMan_Click(object sender, EventArgs e)
        {

        }

        private void lblPasswordCust_Click(object sender, EventArgs e)
        {

        }

        private void lblPasswordMan_Click(object sender, EventArgs e)
        {

        }


        private void txtNameCust_TextChanged(object sender, EventArgs e)
        {
            userName = txtNameCust.Text;
        }

        private void txtSurnameCust_TextChanged(object sender, EventArgs e)
        {
            userSurname = txtSurnameCust.Text;
        }

        private void txtPasswordCust_TextChanged(object sender, EventArgs e)
        {
            userPassword = txtPasswordCust.Text;
        }



        private void txtNameMan_TextChanged(object sender, EventArgs e)
        {
            userName = txtNameMan.Text;
        }

        private void txtSurnameMan_TextChanged(object sender, EventArgs e)
        {
            userSurname = txtSurnameMan.Text;
        }

        private void txtPasswordMan_TextChanged(object sender, EventArgs e)
        {
            userPassword = txtPasswordMan.Text;
        }



        private void checkCustom_CheckedChanged(object sender, EventArgs e)
        {
            if (checkCustom.Checked)
            {
                txtPasswordCust.PasswordChar = '\0';
            }
            else
            {
                txtPasswordCust.PasswordChar = '*';
            }
        }

        private void checkMan_CheckedChanged(object sender, EventArgs e)
        {
            if (checkMan.Checked)
            {
                txtPasswordMan.PasswordChar = '\0';
            }
            else
            {
                txtPasswordMan.PasswordChar = '*';
            }
        }



        private void btnLoginCust_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source = DESKTOP-EMM47NV; Initial Catalog = StockControlSystem; Integrated Security = true";
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();

            SqlDataAdapter adapter = new SqlDataAdapter("SELECT [ID],[USER_NAME],[USER_SURNAME],[PASSWORD],[TITLE_ID],[LANGUAGE],[COUNTRY],[CITY],[COMPANY_ID] FROM [dbo].[USER] WHERE USER_NAME = '"+ txtNameCust.Text.ToString().Trim() + "' AND USER_SURNAME = '"+ txtSurnameCust.Text.ToString().Trim() + "' AND PASSWORD = '"+ txtPasswordCust.Text.ToString().Trim() + "' AND TITLE_ID = 3", connection);
            DataTable dataTable = new DataTable();
            adapter.Fill(dataTable);

            try
            {
                //Debug.WriteLine(dataTable.Rows[0][0].ToString()); elemanlara bu şekilde ulaşabilirsin
                if (dataTable.Rows[0] != null)
                {
                    Close();
                    th = new Thread(openRequestForm);
                    th.SetApartmentState(ApartmentState.STA);
                    th.Start();
                }
               
            }

            catch(Exception ex)   
            {
                System.Windows.Forms.MessageBox.Show("Incorrect Name, Surname or Password!!!\r\nPlease try again.");

            }
        }

        private void openRequestForm(object obj)
        {
            Application.Run(new FormPopUp());
        }


        private void btnLoginMan_Click(object sender, EventArgs e)
        {
            string connectionString = "Data Source = DESKTOP-EMM47NV; Initial Catalog = StockControlSystem; Integrated Security = true";
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();

            SqlDataAdapter adapter = new SqlDataAdapter("SELECT [ID],[USER_NAME],[USER_SURNAME],[PASSWORD],[TITLE_ID],[LANGUAGE],[COUNTRY],[CITY],[COMPANY_ID] FROM [dbo].[USER] WHERE USER_NAME = '" + txtNameMan.Text.ToString().Trim() + "' AND USER_SURNAME = '" + txtSurnameMan.Text.ToString().Trim() + "' AND PASSWORD = '" + txtPasswordMan.Text.ToString().Trim() + "' AND TITLE_ID = 2", connection);
            DataTable dataTable = new DataTable();
            adapter.Fill(dataTable);

            try
            {
                //Debug.WriteLine(dataTable.Rows[0][0].ToString()); elemanlara bu şekilde ulaşabilirsin
                if (dataTable.Rows[0] != null)
                {
                    Close();
                    th = new Thread(openOperationForm);
                    th.SetApartmentState(ApartmentState.STA);
                    th.Start();
                }

            }

            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("Incorrect Name, Surname or Password!!!\r\nPlease try again.");

            }
        }

        private void openOperationForm(object obj)
        {
            Application.Run(new FormPopUp());
        }


        private void btnDeleteCust_Click(object sender, EventArgs e)
        {
            txtNameCust.Clear();
            txtSurnameCust.Clear();
            txtPasswordCust.Clear();
            
        }

        private void btnDeleteMan_Click(object sender, EventArgs e)
        {
            txtNameMan.Clear();
            txtSurnameMan.Clear();
            txtPasswordMan.Clear();
        }

        private void btnCancelMan_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCancelCust_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
