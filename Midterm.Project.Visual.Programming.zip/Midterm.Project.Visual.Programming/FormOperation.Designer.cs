﻿namespace Midterm.Project.Visual.Programming
{
    partial class FormOperation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gridOperation = new System.Windows.Forms.DataGridView();
            this.labelOperationID = new System.Windows.Forms.Label();
            this.comboOperationID = new System.Windows.Forms.ComboBox();
            this.buttonConfirm = new System.Windows.Forms.Button();
            this.gridUpdatedOperation = new System.Windows.Forms.DataGridView();
            this.gridStock = new System.Windows.Forms.DataGridView();
            this.gridUpdatedStock = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.gridOperation)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridUpdatedOperation)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridStock)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridUpdatedStock)).BeginInit();
            this.SuspendLayout();
            // 
            // gridOperation
            // 
            this.gridOperation.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gridOperation.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            this.gridOperation.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridOperation.Location = new System.Drawing.Point(-274, -26);
            this.gridOperation.Name = "gridOperation";
            this.gridOperation.Size = new System.Drawing.Size(1043, 293);
            this.gridOperation.TabIndex = 0;
            this.gridOperation.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gridOperation_CellContentClick);
            // 
            // labelOperationID
            // 
            this.labelOperationID.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelOperationID.AutoSize = true;
            this.labelOperationID.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelOperationID.ForeColor = System.Drawing.Color.DarkBlue;
            this.labelOperationID.Location = new System.Drawing.Point(185, 333);
            this.labelOperationID.Name = "labelOperationID";
            this.labelOperationID.Size = new System.Drawing.Size(100, 17);
            this.labelOperationID.TabIndex = 0;
            this.labelOperationID.Text = "Operation ID";
            this.labelOperationID.Click += new System.EventHandler(this.labelOperationID_Click);
            // 
            // comboOperationID
            // 
            this.comboOperationID.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboOperationID.FormattingEnabled = true;
            this.comboOperationID.Location = new System.Drawing.Point(291, 332);
            this.comboOperationID.Name = "comboOperationID";
            this.comboOperationID.Size = new System.Drawing.Size(186, 21);
            this.comboOperationID.TabIndex = 1;
            this.comboOperationID.SelectedIndexChanged += new System.EventHandler(this.comboOperationID_SelectedIndexChanged);
            // 
            // buttonConfirm
            // 
            this.buttonConfirm.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonConfirm.BackColor = System.Drawing.Color.White;
            this.buttonConfirm.FlatAppearance.BorderColor = System.Drawing.Color.DarkBlue;
            this.buttonConfirm.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.buttonConfirm.ForeColor = System.Drawing.Color.DarkBlue;
            this.buttonConfirm.Location = new System.Drawing.Point(483, 324);
            this.buttonConfirm.Name = "buttonConfirm";
            this.buttonConfirm.Size = new System.Drawing.Size(174, 32);
            this.buttonConfirm.TabIndex = 2;
            this.buttonConfirm.Text = "Confirm This Operation";
            this.buttonConfirm.UseVisualStyleBackColor = false;
            this.buttonConfirm.Click += new System.EventHandler(this.buttonConfirm_Click);
            // 
            // gridUpdatedOperation
            // 
            this.gridUpdatedOperation.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gridUpdatedOperation.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            this.gridUpdatedOperation.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridUpdatedOperation.Location = new System.Drawing.Point(-283, 400);
            this.gridUpdatedOperation.Name = "gridUpdatedOperation";
            this.gridUpdatedOperation.Size = new System.Drawing.Size(1052, 215);
            this.gridUpdatedOperation.TabIndex = 0;
            // 
            // gridStock
            // 
            this.gridStock.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gridStock.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            this.gridStock.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridStock.Location = new System.Drawing.Point(775, -26);
            this.gridStock.Name = "gridStock";
            this.gridStock.Size = new System.Drawing.Size(285, 293);
            this.gridStock.TabIndex = 0;
            // 
            // gridUpdatedStock
            // 
            this.gridUpdatedStock.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.gridUpdatedStock.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            this.gridUpdatedStock.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridUpdatedStock.Location = new System.Drawing.Point(775, 400);
            this.gridUpdatedStock.Name = "gridUpdatedStock";
            this.gridUpdatedStock.Size = new System.Drawing.Size(285, 215);
            this.gridUpdatedStock.TabIndex = 0;
            // 
            // FormOperation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(800, 509);
            this.Controls.Add(this.gridUpdatedStock);
            this.Controls.Add(this.gridStock);
            this.Controls.Add(this.gridUpdatedOperation);
            this.Controls.Add(this.buttonConfirm);
            this.Controls.Add(this.labelOperationID);
            this.Controls.Add(this.comboOperationID);
            this.Controls.Add(this.gridOperation);
            this.Name = "FormOperation";
            this.Text = "Stock Control System - Manage Operations ";
            this.Load += new System.EventHandler(this.FormOperation_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gridOperation)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridUpdatedOperation)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridStock)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridUpdatedStock)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView gridOperation;
        private System.Windows.Forms.Label labelOperationID;
        private System.Windows.Forms.ComboBox comboOperationID;
        private System.Windows.Forms.Button buttonConfirm;
        private System.Windows.Forms.DataGridView gridUpdatedOperation;
        private System.Windows.Forms.DataGridView gridStock;
        private System.Windows.Forms.DataGridView gridUpdatedStock;
    }
}