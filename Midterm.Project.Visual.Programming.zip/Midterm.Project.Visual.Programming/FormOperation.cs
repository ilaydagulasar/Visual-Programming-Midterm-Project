﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace Midterm.Project.Visual.Programming
{
    public partial class FormOperation : Form
    {
        Thread th;

        public FormOperation()
        {
            InitializeComponent();
        }

        private void gridOperation_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void FormOperation_Load(object sender, EventArgs e)
        {

            string connectionString = "Data Source = DESKTOP-EMM47NV; Initial Catalog = StockControlSystem; Integrated Security = true";
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();

            SqlDataAdapter adapter = new SqlDataAdapter("SELECT [ID],[EMPLOYEE_PERFORMING_OPERATION_ID],[CUSTOMER_COMPANY_MAKING_REQUEST_ID],[MANUFACTURER_COMPANY_SENDING_REQUEST_ID],[WAREHOUSE_SENDING_REQUEST_ID],[PRODUCT_ID],[QUANTITY],[ORDER_DATE],[RECIEVE_DATE],[STATU] FROM [dbo].[OPERATION] WHERE STATU = 'On Process          '", connection);
            DataTable dataTable = new DataTable();
            adapter.Fill(dataTable);

            gridOperation.DataSource = dataTable;

            try
            {
                //Debug.WriteLine(dataTable.Rows[0][0].ToString()); elemanlara bu şekilde ulaşabilirsin
                if (dataTable.Rows[0] != null)
                {
                    string productIDs = "";
                    
                    for (int i = 0; i < dataTable.Rows.Count; i++)
                    {
                        comboOperationID.Items.Add(dataTable.Rows[i][0]);

                        if (i==0)
                        {
                            productIDs += dataTable.Rows[i][5];
                        }
                        else
                        {
                            productIDs += ","+dataTable.Rows[i][5];
                        }

                    }

                    SqlDataAdapter adapter3 = new SqlDataAdapter("SELECT [PRODUCT_ID],[STOCK_QUANTITY] FROM [dbo].[STOCK] WHERE PRODUCT_ID IN ("+ productIDs + ") ", connection);
                    DataTable dataTable3 = new DataTable();
                    adapter3.Fill(dataTable3);

                    gridStock.DataSource = dataTable3;

                }

            }

            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("There is an error occured while checking the operations.");
            }

            SqlDataAdapter adapter2 = new SqlDataAdapter("SELECT [ID],[EMPLOYEE_PERFORMING_OPERATION_ID],[CUSTOMER_COMPANY_MAKING_REQUEST_ID],[MANUFACTURER_COMPANY_SENDING_REQUEST_ID],[WAREHOUSE_SENDING_REQUEST_ID],[PRODUCT_ID],[QUANTITY],[ORDER_DATE],[RECIEVE_DATE],[STATU] FROM [dbo].[OPERATION] WHERE STATU = 'Operation Confirmed '", connection);
            DataTable dataTable2 = new DataTable();
            adapter2.Fill(dataTable2);

            gridUpdatedOperation.DataSource = dataTable2;

            string updatedProductIDs = "";

            for (int i = 0; i < dataTable2.Rows.Count; i++)
            {
                if (i == 0)
                {
                    updatedProductIDs += dataTable2.Rows[i][5];
                }
                else
                {
                    updatedProductIDs += "," + dataTable2.Rows[i][5];
                }

            }

            SqlDataAdapter adapter4 = new SqlDataAdapter("SELECT [PRODUCT_ID],[STOCK_QUANTITY] FROM [dbo].[STOCK] WHERE PRODUCT_ID IN (" + updatedProductIDs + ") ", connection);
            DataTable dataTable4 = new DataTable();
            adapter4.Fill(dataTable4);

            gridUpdatedStock.DataSource = dataTable4;

        }

        private void labelOperationID_Click(object sender, EventArgs e)
        {

        }
        private void comboOperationID_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void buttonConfirm_Click(object sender, EventArgs e)
        {
            

            try
            {
                string operationID = comboOperationID.Text;

                string connectionString = "Data Source = DESKTOP-EMM47NV; Initial Catalog = StockControlSystem; Integrated Security = true";
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();

                string sqlCommend = "UPDATE [dbo].[OPERATION] SET [STATU] = 'Operation Confirmed' WHERE ID = '"+ operationID + "'";

                SqlCommand command = new SqlCommand(sqlCommend, connection);

                int result = 0;

                result = Convert.ToInt32(command.ExecuteNonQuery());

                /////////////////////

                string sqlCommend2 = "UPDATE [dbo].[STOCK] SET [STOCK_QUANTITY] = [STOCK_QUANTITY] - ( SELECT QUANTITY FROM OPERATION WHERE ID = " + operationID + ") WHERE PRODUCT_ID IN ( SELECT PRODUCT_ID FROM OPERATION WHERE ID = " + operationID + ")";

                SqlCommand command2 = new SqlCommand(sqlCommend2, connection);

                int result2 = 0;

                result2 = Convert.ToInt32(command2.ExecuteNonQuery());



                if (result != 0 & result2 != 0)
                {
                    System.Windows.Forms.MessageBox.Show("Operation confirmed. Please update product stocks if it is necessary.");
                }
                else
                {
                    System.Windows.Forms.MessageBox.Show("There is an error occured while confirming the operation");
                }

            }

            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("There is an error occured.");

            }

            FormOperation_Load(this, e);
        }

    }
}
