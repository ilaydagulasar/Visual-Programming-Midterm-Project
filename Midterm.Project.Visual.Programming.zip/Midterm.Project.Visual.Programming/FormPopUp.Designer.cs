﻿namespace Midterm.Project.Visual.Programming
{
    partial class FormPopUp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormPopUp));
            this.buttonManageOperations = new System.Windows.Forms.Button();
            this.buttonUpdateStocks = new System.Windows.Forms.Button();
            this.lblTask = new System.Windows.Forms.Label();
            this.lblLogo = new System.Windows.Forms.Label();
            this.picLogo = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonManageOperations
            // 
            this.buttonManageOperations.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonManageOperations.BackColor = System.Drawing.Color.White;
            this.buttonManageOperations.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.buttonManageOperations.ForeColor = System.Drawing.Color.Navy;
            this.buttonManageOperations.Location = new System.Drawing.Point(127, 222);
            this.buttonManageOperations.Name = "buttonManageOperations";
            this.buttonManageOperations.Size = new System.Drawing.Size(151, 80);
            this.buttonManageOperations.TabIndex = 6;
            this.buttonManageOperations.Text = "Manage Operations";
            this.buttonManageOperations.UseVisualStyleBackColor = false;
            this.buttonManageOperations.Click += new System.EventHandler(this.buttonManageOperations_Click);
            // 
            // buttonUpdateStocks
            // 
            this.buttonUpdateStocks.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonUpdateStocks.BackColor = System.Drawing.Color.White;
            this.buttonUpdateStocks.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.buttonUpdateStocks.ForeColor = System.Drawing.Color.Navy;
            this.buttonUpdateStocks.Location = new System.Drawing.Point(300, 222);
            this.buttonUpdateStocks.Name = "buttonUpdateStocks";
            this.buttonUpdateStocks.Size = new System.Drawing.Size(151, 80);
            this.buttonUpdateStocks.TabIndex = 7;
            this.buttonUpdateStocks.Text = "Update Stocks";
            this.buttonUpdateStocks.UseVisualStyleBackColor = false;
            this.buttonUpdateStocks.Click += new System.EventHandler(this.buttonUpdateStocks_Click);
            // 
            // lblTask
            // 
            this.lblTask.AutoSize = true;
            this.lblTask.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblTask.ForeColor = System.Drawing.Color.Navy;
            this.lblTask.Location = new System.Drawing.Point(148, 165);
            this.lblTask.Name = "lblTask";
            this.lblTask.Size = new System.Drawing.Size(279, 17);
            this.lblTask.TabIndex = 8;
            this.lblTask.Text = "Please select the task you want to do";
            // 
            // lblLogo
            // 
            this.lblLogo.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblLogo.AutoSize = true;
            this.lblLogo.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblLogo.ForeColor = System.Drawing.Color.DarkBlue;
            this.lblLogo.Location = new System.Drawing.Point(191, 105);
            this.lblLogo.Name = "lblLogo";
            this.lblLogo.Size = new System.Drawing.Size(207, 24);
            this.lblLogo.TabIndex = 9;
            this.lblLogo.Text = "Stock Control System";
            // 
            // picLogo
            // 
            this.picLogo.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.picLogo.Image = ((System.Drawing.Image)(resources.GetObject("picLogo.Image")));
            this.picLogo.Location = new System.Drawing.Point(246, 12);
            this.picLogo.Name = "picLogo";
            this.picLogo.Size = new System.Drawing.Size(89, 81);
            this.picLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picLogo.TabIndex = 10;
            this.picLogo.TabStop = false;
            // 
            // FormPopUp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(584, 341);
            this.Controls.Add(this.lblLogo);
            this.Controls.Add(this.picLogo);
            this.Controls.Add(this.lblTask);
            this.Controls.Add(this.buttonUpdateStocks);
            this.Controls.Add(this.buttonManageOperations);
            this.Name = "FormPopUp";
            this.Text = "Select the Task";
            this.Load += new System.EventHandler(this.FormPopUp_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonManageOperations;
        private System.Windows.Forms.Button buttonUpdateStocks;
        private System.Windows.Forms.Label lblTask;
        private System.Windows.Forms.Label lblLogo;
        private System.Windows.Forms.PictureBox picLogo;
    }
}