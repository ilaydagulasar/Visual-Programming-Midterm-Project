﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Midterm.Project.Visual.Programming
{
    public partial class FormPopUp : Form
    {

        Thread th;
        public FormPopUp()
        {
            InitializeComponent();
        }

        private void FormPopUp_Load(object sender, EventArgs e)
        {

        }

        private void buttonManageOperations_Click(object sender, EventArgs e)
        {
            Close();
            th = new Thread(openOperationForm);
            th.SetApartmentState(ApartmentState.STA);
            th.Start();
        }

        private void openOperationForm(object obj)
        {
            Application.Run(new FormOperation());
        }

        private void buttonUpdateStocks_Click(object sender, EventArgs e)
        {
            Close();
            th = new Thread(openRequestForm);
            th.SetApartmentState(ApartmentState.STA);
            th.Start();
        }

        private void openRequestForm(object obj)
        {
            Application.Run(new FormRequest());
        }
    }
}
