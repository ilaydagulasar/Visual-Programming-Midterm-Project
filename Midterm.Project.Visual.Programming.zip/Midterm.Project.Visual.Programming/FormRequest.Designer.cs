﻿namespace Midterm.Project.Visual.Programming
{
    partial class FormRequest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormRequest));
            this.lblLogoRequest = new System.Windows.Forms.Label();
            this.labelWarehouse = new System.Windows.Forms.Label();
            this.labelCity = new System.Windows.Forms.Label();
            this.comboCity = new System.Windows.Forms.ComboBox();
            this.comboWarehouse = new System.Windows.Forms.ComboBox();
            this.buttonRequest = new System.Windows.Forms.Button();
            this.labelCompany = new System.Windows.Forms.Label();
            this.comboCompany = new System.Windows.Forms.ComboBox();
            this.lblExp1 = new System.Windows.Forms.Label();
            this.picLogoRequest = new System.Windows.Forms.PictureBox();
            this.comboProduct = new System.Windows.Forms.ComboBox();
            this.lblStock = new System.Windows.Forms.Label();
            this.labelAmount = new System.Windows.Forms.Label();
            this.labelProduct = new System.Windows.Forms.Label();
            this.labelExp2 = new System.Windows.Forms.Label();
            this.Calendar = new System.Windows.Forms.MonthCalendar();
            this.labelExp3 = new System.Windows.Forms.Label();
            this.labelCategory = new System.Windows.Forms.Label();
            this.comboCategory = new System.Windows.Forms.ComboBox();
            this.numNewStock = new System.Windows.Forms.NumericUpDown();
            this.buttonReset = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.picLogoRequest)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numNewStock)).BeginInit();
            this.SuspendLayout();
            // 
            // lblLogoRequest
            // 
            this.lblLogoRequest.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblLogoRequest.AutoSize = true;
            this.lblLogoRequest.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblLogoRequest.ForeColor = System.Drawing.Color.DarkBlue;
            this.lblLogoRequest.Location = new System.Drawing.Point(290, 104);
            this.lblLogoRequest.Name = "lblLogoRequest";
            this.lblLogoRequest.Size = new System.Drawing.Size(207, 24);
            this.lblLogoRequest.TabIndex = 0;
            this.lblLogoRequest.Text = "Stock Control System";
            // 
            // labelWarehouse
            // 
            this.labelWarehouse.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelWarehouse.AutoSize = true;
            this.labelWarehouse.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelWarehouse.ForeColor = System.Drawing.Color.DarkBlue;
            this.labelWarehouse.Location = new System.Drawing.Point(488, 217);
            this.labelWarehouse.Name = "labelWarehouse";
            this.labelWarehouse.Size = new System.Drawing.Size(90, 17);
            this.labelWarehouse.TabIndex = 5;
            this.labelWarehouse.Text = "Warehouse";
            // 
            // labelCity
            // 
            this.labelCity.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelCity.AutoSize = true;
            this.labelCity.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelCity.ForeColor = System.Drawing.Color.DarkBlue;
            this.labelCity.Location = new System.Drawing.Point(299, 217);
            this.labelCity.Name = "labelCity";
            this.labelCity.Size = new System.Drawing.Size(35, 17);
            this.labelCity.TabIndex = 6;
            this.labelCity.Text = "City";
            // 
            // comboCity
            // 
            this.comboCity.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboCity.Enabled = false;
            this.comboCity.FormattingEnabled = true;
            this.comboCity.Items.AddRange(new object[] {
            "Afghanistan",
            "Albania",
            "Algeria",
            "Andorra",
            "Angola",
            "Antigua & Deps",
            "Argentina",
            "Armenia",
            "Australia",
            "Austria",
            "Azerbaijan",
            "Bahamas",
            "Bahrain",
            "Bangladesh",
            "Barbados",
            "Belarus",
            "Belgium",
            "Belize",
            "Benin",
            "Bhutan",
            "Bolivia",
            "Bosnia Herzegovina",
            "Botswana",
            "Brazil",
            "Brunei",
            "Bulgaria",
            "Burkina",
            "Burundi",
            "Cambodia",
            "Cameroon",
            "Canada",
            "Cape Verde",
            "Central African Rep",
            "Chad",
            "Chile",
            "China",
            "Colombia",
            "Comoros",
            "Congo",
            "Congo {Democratic Rep}",
            "Costa Rica",
            "Croatia",
            "Cuba",
            "Cyprus",
            "Czech Republic",
            "Denmark",
            "Djibouti",
            "Dominica",
            "Dominican Republic",
            "East Timor",
            "Ecuador",
            "Egypt",
            "El Salvador",
            "Equatorial Guinea",
            "Eritrea",
            "Estonia",
            "Ethiopia",
            "Fiji",
            "Finland",
            "France",
            "Gabon",
            "Gambia",
            "Georgia",
            "Germany",
            "Ghana",
            "Greece",
            "Grenada",
            "Guatemala",
            "Guinea",
            "Guinea-Bissau",
            "Guyana",
            "Haiti",
            "Honduras",
            "Hungary",
            "Iceland",
            "India",
            "Indonesia",
            "Iran",
            "Iraq",
            "Ireland {Republic}",
            "Israel",
            "Italy",
            "Ivory Coast",
            "Jamaica",
            "Japan",
            "Jordan",
            "Kazakhstan",
            "Kenya",
            "Kiribati",
            "Korea North",
            "Korea South",
            "Kosovo",
            "Kuwait",
            "Kyrgyzstan",
            "Laos",
            "Latvia",
            "Lebanon",
            "Lesotho",
            "Liberia",
            "Libya",
            "Liechtenstein",
            "Lithuania",
            "Luxembourg",
            "Macedonia",
            "Madagascar",
            "Malawi",
            "Malaysia",
            "Maldives",
            "Mali",
            "Malta",
            "Marshall Islands",
            "Mauritania",
            "Mauritius",
            "Mexico",
            "Micronesia",
            "Moldova",
            "Monaco",
            "Mongolia",
            "Montenegro",
            "Morocco",
            "Mozambique",
            "Myanmar, {Burma}",
            "Namibia",
            "Nauru",
            "Nepal",
            "Netherlands",
            "New Zealand",
            "Nicaragua",
            "Niger",
            "Nigeria",
            "Norway",
            "Oman",
            "Pakistan",
            "Palau",
            "Panama",
            "Papua New Guinea",
            "Paraguay",
            "Peru",
            "Philippines",
            "Poland",
            "Portugal",
            "Qatar",
            "Romania",
            "Russian Federation",
            "Rwanda",
            "St Kitts & Nevis",
            "St Lucia",
            "Saint Vincent & the Grenadines",
            "Samoa",
            "San Marino",
            "Sao Tome & Principe",
            "Saudi Arabia",
            "Senegal",
            "Serbia",
            "Seychelles",
            "Sierra Leone",
            "Singapore",
            "Slovakia",
            "Slovenia",
            "Solomon Islands",
            "Somalia",
            "South Africa",
            "South Sudan",
            "Spain",
            "Sri Lanka",
            "Sudan",
            "Suriname",
            "Swaziland",
            "Sweden",
            "Switzerland",
            "Syria",
            "Taiwan",
            "Tajikistan",
            "Tanzania",
            "Thailand",
            "Togo",
            "Tonga",
            "Trinidad & Tobago",
            "Tunisia",
            "Turkey",
            "Turkmenistan",
            "Tuvalu",
            "Uganda",
            "Ukraine",
            "United Arab Emirates",
            "United Kingdom",
            "United States",
            "Uruguay",
            "Uzbekistan",
            "Vanuatu",
            "Vatican City",
            "Venezuela",
            "Vietnam",
            "Yemen",
            "Zambia",
            "Zimbabwe"});
            this.comboCity.Location = new System.Drawing.Point(336, 214);
            this.comboCity.Name = "comboCity";
            this.comboCity.Size = new System.Drawing.Size(138, 21);
            this.comboCity.TabIndex = 2;
            this.comboCity.SelectedIndexChanged += new System.EventHandler(this.comboCity_SelectedIndexChanged);
            // 
            // comboWarehouse
            // 
            this.comboWarehouse.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboWarehouse.Enabled = false;
            this.comboWarehouse.FormattingEnabled = true;
            this.comboWarehouse.Location = new System.Drawing.Point(584, 216);
            this.comboWarehouse.Name = "comboWarehouse";
            this.comboWarehouse.Size = new System.Drawing.Size(138, 21);
            this.comboWarehouse.TabIndex = 3;
            this.comboWarehouse.SelectedIndexChanged += new System.EventHandler(this.comboWarehouse_SelectedIndexChanged);
            // 
            // buttonRequest
            // 
            this.buttonRequest.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonRequest.BackColor = System.Drawing.Color.White;
            this.buttonRequest.Enabled = false;
            this.buttonRequest.FlatAppearance.BorderColor = System.Drawing.Color.DarkBlue;
            this.buttonRequest.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.buttonRequest.ForeColor = System.Drawing.Color.DarkBlue;
            this.buttonRequest.Location = new System.Drawing.Point(426, 496);
            this.buttonRequest.Name = "buttonRequest";
            this.buttonRequest.Size = new System.Drawing.Size(138, 32);
            this.buttonRequest.TabIndex = 8;
            this.buttonRequest.Text = "Make a Request";
            this.buttonRequest.UseVisualStyleBackColor = false;
            this.buttonRequest.Click += new System.EventHandler(this.buttonRequest_Click);
            // 
            // labelCompany
            // 
            this.labelCompany.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelCompany.AutoSize = true;
            this.labelCompany.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelCompany.ForeColor = System.Drawing.Color.DarkBlue;
            this.labelCompany.Location = new System.Drawing.Point(67, 218);
            this.labelCompany.Name = "labelCompany";
            this.labelCompany.Size = new System.Drawing.Size(74, 17);
            this.labelCompany.TabIndex = 12;
            this.labelCompany.Text = "Company";
            this.labelCompany.Click += new System.EventHandler(this.labelCompany_Click);
            // 
            // comboCompany
            // 
            this.comboCompany.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboCompany.FormattingEnabled = true;
            this.comboCompany.Location = new System.Drawing.Point(140, 216);
            this.comboCompany.Name = "comboCompany";
            this.comboCompany.Size = new System.Drawing.Size(138, 21);
            this.comboCompany.TabIndex = 1;
            this.comboCompany.SelectedIndexChanged += new System.EventHandler(this.comboCompany_SelectedIndexChanged);
            // 
            // lblExp1
            // 
            this.lblExp1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblExp1.AutoSize = true;
            this.lblExp1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lblExp1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblExp1.Location = new System.Drawing.Point(115, 175);
            this.lblExp1.Name = "lblExp1";
            this.lblExp1.Size = new System.Drawing.Size(559, 17);
            this.lblExp1.TabIndex = 0;
            this.lblExp1.Text = "Please select the company, city and warehouse from which you will request the pro" +
    "duct.\r\n";
            // 
            // picLogoRequest
            // 
            this.picLogoRequest.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.picLogoRequest.Image = ((System.Drawing.Image)(resources.GetObject("picLogoRequest.Image")));
            this.picLogoRequest.Location = new System.Drawing.Point(353, 20);
            this.picLogoRequest.Name = "picLogoRequest";
            this.picLogoRequest.Size = new System.Drawing.Size(89, 81);
            this.picLogoRequest.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picLogoRequest.TabIndex = 2;
            this.picLogoRequest.TabStop = false;
            // 
            // comboProduct
            // 
            this.comboProduct.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboProduct.Enabled = false;
            this.comboProduct.FormattingEnabled = true;
            this.comboProduct.Location = new System.Drawing.Point(508, 261);
            this.comboProduct.Name = "comboProduct";
            this.comboProduct.Size = new System.Drawing.Size(186, 21);
            this.comboProduct.TabIndex = 5;
            this.comboProduct.SelectedIndexChanged += new System.EventHandler(this.comboProduct_SelectedIndexChanged);
            // 
            // lblStock
            // 
            this.lblStock.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblStock.AutoSize = true;
            this.lblStock.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblStock.Location = new System.Drawing.Point(299, 316);
            this.lblStock.Name = "lblStock";
            this.lblStock.Size = new System.Drawing.Size(0, 17);
            this.lblStock.TabIndex = 16;
            this.lblStock.Click += new System.EventHandler(this.label5_Click);
            // 
            // labelAmount
            // 
            this.labelAmount.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelAmount.AutoSize = true;
            this.labelAmount.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelAmount.ForeColor = System.Drawing.Color.DarkBlue;
            this.labelAmount.Location = new System.Drawing.Point(455, 444);
            this.labelAmount.Name = "labelAmount";
            this.labelAmount.Size = new System.Drawing.Size(152, 17);
            this.labelAmount.TabIndex = 0;
            this.labelAmount.Text = "Number of Products";
            // 
            // labelProduct
            // 
            this.labelProduct.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelProduct.AutoSize = true;
            this.labelProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelProduct.ForeColor = System.Drawing.Color.DarkBlue;
            this.labelProduct.Location = new System.Drawing.Point(439, 265);
            this.labelProduct.Name = "labelProduct";
            this.labelProduct.Size = new System.Drawing.Size(64, 17);
            this.labelProduct.TabIndex = 19;
            this.labelProduct.Text = "Product";
            // 
            // labelExp2
            // 
            this.labelExp2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelExp2.AutoSize = true;
            this.labelExp2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelExp2.Location = new System.Drawing.Point(369, 402);
            this.labelExp2.Name = "labelExp2";
            this.labelExp2.Size = new System.Drawing.Size(378, 17);
            this.labelExp2.TabIndex = 0;
            this.labelExp2.Text = "Please enter the number of the product to make a request.";
            // 
            // Calendar
            // 
            this.Calendar.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Calendar.Enabled = false;
            this.Calendar.Location = new System.Drawing.Point(70, 375);
            this.Calendar.Name = "Calendar";
            this.Calendar.TabIndex = 6;
            this.Calendar.DateChanged += new System.Windows.Forms.DateRangeEventHandler(this.Calendar_DateChanged);
            // 
            // labelExp3
            // 
            this.labelExp3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelExp3.AutoSize = true;
            this.labelExp3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelExp3.Location = new System.Drawing.Point(68, 353);
            this.labelExp3.Name = "labelExp3";
            this.labelExp3.Size = new System.Drawing.Size(236, 13);
            this.labelExp3.TabIndex = 0;
            this.labelExp3.Text = "Which date do you want to receive the product?";
            // 
            // labelCategory
            // 
            this.labelCategory.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelCategory.AutoSize = true;
            this.labelCategory.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelCategory.ForeColor = System.Drawing.Color.DarkBlue;
            this.labelCategory.Location = new System.Drawing.Point(87, 264);
            this.labelCategory.Name = "labelCategory";
            this.labelCategory.Size = new System.Drawing.Size(73, 17);
            this.labelCategory.TabIndex = 24;
            this.labelCategory.Text = "Category";
            this.labelCategory.Click += new System.EventHandler(this.labelCategory_Click);
            // 
            // comboCategory
            // 
            this.comboCategory.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboCategory.Enabled = false;
            this.comboCategory.FormattingEnabled = true;
            this.comboCategory.Location = new System.Drawing.Point(166, 261);
            this.comboCategory.Name = "comboCategory";
            this.comboCategory.Size = new System.Drawing.Size(199, 21);
            this.comboCategory.TabIndex = 4;
            this.comboCategory.SelectedIndexChanged += new System.EventHandler(this.comboCategory_SelectedIndexChanged);
            // 
            // numNewStock
            // 
            this.numNewStock.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.numNewStock.Enabled = false;
            this.numNewStock.Location = new System.Drawing.Point(613, 444);
            this.numNewStock.Name = "numNewStock";
            this.numNewStock.Size = new System.Drawing.Size(81, 20);
            this.numNewStock.TabIndex = 7;
            this.numNewStock.ValueChanged += new System.EventHandler(this.numNewStock_ValueChanged);
            // 
            // buttonReset
            // 
            this.buttonReset.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonReset.BackColor = System.Drawing.Color.White;
            this.buttonReset.FlatAppearance.BorderColor = System.Drawing.Color.DarkBlue;
            this.buttonReset.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.buttonReset.ForeColor = System.Drawing.Color.DarkBlue;
            this.buttonReset.Location = new System.Drawing.Point(584, 496);
            this.buttonReset.Name = "buttonReset";
            this.buttonReset.Size = new System.Drawing.Size(138, 32);
            this.buttonReset.TabIndex = 9;
            this.buttonReset.Text = "Reset";
            this.buttonReset.UseVisualStyleBackColor = false;
            this.buttonReset.Click += new System.EventHandler(this.buttonReset_Click);
            // 
            // FormRequest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(800, 562);
            this.Controls.Add(this.buttonReset);
            this.Controls.Add(this.numNewStock);
            this.Controls.Add(this.labelCategory);
            this.Controls.Add(this.comboCategory);
            this.Controls.Add(this.labelExp3);
            this.Controls.Add(this.Calendar);
            this.Controls.Add(this.labelExp2);
            this.Controls.Add(this.labelProduct);
            this.Controls.Add(this.labelAmount);
            this.Controls.Add(this.lblStock);
            this.Controls.Add(this.comboProduct);
            this.Controls.Add(this.lblExp1);
            this.Controls.Add(this.comboCompany);
            this.Controls.Add(this.labelCompany);
            this.Controls.Add(this.buttonRequest);
            this.Controls.Add(this.comboWarehouse);
            this.Controls.Add(this.comboCity);
            this.Controls.Add(this.labelCity);
            this.Controls.Add(this.labelWarehouse);
            this.Controls.Add(this.lblLogoRequest);
            this.Controls.Add(this.picLogoRequest);
            this.Name = "FormRequest";
            this.Text = "Stock Control System - Inventory Request";
            this.Load += new System.EventHandler(this.HomeForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picLogoRequest)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numNewStock)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblLogoRequest;
        private System.Windows.Forms.PictureBox picLogoRequest;
        private System.Windows.Forms.Label labelWarehouse;
        private System.Windows.Forms.Label labelCity;
        private System.Windows.Forms.ComboBox comboCity;
        private System.Windows.Forms.ComboBox comboWarehouse;
        private System.Windows.Forms.Button buttonRequest;
        private System.Windows.Forms.Label labelCompany;
        private System.Windows.Forms.ComboBox comboCompany;
        private System.Windows.Forms.Label lblExp1;
        private System.Windows.Forms.ComboBox comboProduct;
        private System.Windows.Forms.Label lblStock;
        private System.Windows.Forms.Label labelAmount;
        private System.Windows.Forms.Label labelProduct;
        private System.Windows.Forms.Label labelExp2;
        private System.Windows.Forms.MonthCalendar Calendar;
        private System.Windows.Forms.Label labelExp3;
        private System.Windows.Forms.Label labelCategory;
        private System.Windows.Forms.ComboBox comboCategory;
        private System.Windows.Forms.NumericUpDown numNewStock;
        private System.Windows.Forms.Button buttonReset;
    }
}