﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Midterm.Project.Visual.Programming
{
    public partial class FormRequest : Form
    {
        public FormRequest()
        {
            InitializeComponent();
        }

        private void HomeForm_Load(object sender, EventArgs e)
        {
           
            
            string connectionString = "Data Source = DESKTOP-EMM47NV; Initial Catalog = StockControlSystem; Integrated Security = true";
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();

            SqlDataAdapter adapter = new SqlDataAdapter("SELECT [ID],[COMPANY_NAME],[COMPANY_TAX_ID],[COMPANY_ORIGIN],[USER_TYPE] FROM [dbo].[COMPANY] WHERE USER_TYPE = 'Manufacturer        '", connection);
            DataTable dataTable = new DataTable();
            adapter.Fill(dataTable);

            comboCompany.Items.Clear();

            try
            {
                //Debug.WriteLine(dataTable.Rows[0][0].ToString()); elemanlara bu şekilde ulaşabilirsin
                if (dataTable.Rows[0] != null)
                {
                    for (int i = 0; i < dataTable.Rows.Count; i++)
                    {
                        comboCompany.Items.Add(dataTable.Rows[i][1]);
                    }
                }

            }

            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("There is an error occured while checking the companies.");
            }
        }


        private void label5_Click(object sender, EventArgs e)
        {

        }


        private void labelCategory_Click(object sender, EventArgs e)
        {

        }

        private void labelCompany_Click(object sender, EventArgs e)
        {

        }

        private void comboCity_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboWarehouse.Enabled = true;
            comboCompany.Enabled = false;

            string company = comboCompany.SelectedItem.ToString();
            string city = comboCity.SelectedItem.ToString();

            string connectionString = "Data Source = DESKTOP-EMM47NV; Initial Catalog = StockControlSystem; Integrated Security = true";
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();

            SqlDataAdapter adapter = new SqlDataAdapter("SELECT [ID],[WAREHOUSE_NAME],[COUNTRY],[CITY],[ADRESS],[COMPANY_ID] FROM WAREHOUSE WHERE COMPANY_ID IN (SELECT ID FROM COMPANY WHERE COMPANY_NAME = '" + company + "' AND CITY = '"+ city +"' )", connection);
            DataTable dataTable = new DataTable();
            adapter.Fill(dataTable);

            comboWarehouse.Items.Clear();

            try
            {
                //Debug.WriteLine(dataTable.Rows[0][0].ToString()); elemanlara bu şekilde ulaşabilirsin
                if (dataTable.Rows[0] != null)
                {
                    for (int i = 0; i < dataTable.Rows.Count; i++)
                    {
                        comboWarehouse.Items.Add(dataTable.Rows[i][1]);
                    }
                }

            }

            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("There is an error occured while checking the cities.");
            }
        }

        private void comboCompany_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboCity.Enabled = true;
            

            string company = comboCompany.SelectedItem.ToString();
            Debug.WriteLine(company);

            string connectionString = "Data Source = DESKTOP-EMM47NV; Initial Catalog = StockControlSystem; Integrated Security = true";
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();

            SqlDataAdapter adapter = new SqlDataAdapter("SELECT [ID],[WAREHOUSE_NAME],[COUNTRY],[CITY],[ADRESS],[COMPANY_ID] FROM WAREHOUSE WHERE COMPANY_ID IN (SELECT ID FROM COMPANY WHERE COMPANY_NAME = '" + company +"' )", connection);
            DataTable dataTable = new DataTable();
            adapter.Fill(dataTable);

            comboCity.Items.Clear();

            try
            {
                //Debug.WriteLine(dataTable.Rows[0][0].ToString()); elemanlara bu şekilde ulaşabilirsin
                if (dataTable.Rows[0] != null)
                {
                    for (int i = 0; i < dataTable.Rows.Count; i++)
                    {
                        comboCity.Items.Add(dataTable.Rows[i][3]);
                    }
                }

            }

            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("There is an error occured while checking the companies.");
            }
        }

        private void comboWarehouse_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboCategory.Enabled = true;
            comboCity.Enabled = false;

            string warehouse = comboWarehouse.SelectedItem.ToString();

            string connectionString = "Data Source = DESKTOP-EMM47NV; Initial Catalog = StockControlSystem; Integrated Security = true";
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();

            SqlDataAdapter adapter = new SqlDataAdapter("SELECT [ID],[PRODUCT_NAME],[CATEGORY],[PRODUCT_CODE],[WAREHOUSE_ID] FROM [dbo].[PRODUCT] WHERE WAREHOUSE_ID IN (SELECT ID FROM WAREHOUSE WHERE WAREHOUSE_NAME = '"+ warehouse + "')", connection);
            DataTable dataTable = new DataTable();
            adapter.Fill(dataTable);

            comboCategory.Items.Clear();

            string categories = "";

            try
            {
                //Debug.WriteLine(dataTable.Rows[0][0].ToString()); elemanlara bu şekilde ulaşabilirsin
                if (dataTable.Rows[0] != null)
                {
                    for (int i = 0; i < dataTable.Rows.Count; i++)
                    {
                        
                        if (categories != dataTable.Rows[i][2].ToString().Trim())
                        {
                            categories = dataTable.Rows[i][2].ToString().Trim();
                            comboCategory.Items.Add(dataTable.Rows[i][2]);
                        }
                        
                    }
                }

            }

            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("There is an error occured while checking the warehouses.");
            }
        }

        private void comboCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboProduct.Enabled = true;
            comboWarehouse.Enabled = false;

            string warehouse = comboWarehouse.SelectedItem.ToString();
            string category = comboCategory.SelectedItem.ToString();

            string connectionString = "Data Source = DESKTOP-EMM47NV; Initial Catalog = StockControlSystem; Integrated Security = true";
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();

            SqlDataAdapter adapter = new SqlDataAdapter("SELECT [ID],[PRODUCT_NAME],[CATEGORY],[PRODUCT_CODE],[WAREHOUSE_ID] FROM [dbo].[PRODUCT] WHERE WAREHOUSE_ID IN (SELECT ID FROM WAREHOUSE WHERE WAREHOUSE_NAME = '" + warehouse + "') AND CATEGORY = '"+ category + "'", connection);
            DataTable dataTable = new DataTable();
            adapter.Fill(dataTable);

            comboProduct.Items.Clear();

            try
            {
                //Debug.WriteLine(dataTable.Rows[0][0].ToString()); elemanlara bu şekilde ulaşabilirsin
                if (dataTable.Rows[0] != null)
                {
                    for (int i = 0; i < dataTable.Rows.Count; i++)
                    {
                        comboProduct.Items.Add(dataTable.Rows[i][1]);
                    }
                }

            }

            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("There is an error occured while checking the categories.");
            }
        }

        private void comboProduct_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            comboCategory.Enabled = false;

            string product = comboProduct.SelectedItem.ToString();
            string warehouse = comboWarehouse.SelectedItem.ToString();

            string connectionString = "Data Source = DESKTOP-EMM47NV; Initial Catalog = StockControlSystem; Integrated Security = true";
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();

            SqlDataAdapter adapter = new SqlDataAdapter("SELECT STOCK_QUANTITY FROM STOCK WHERE PRODUCT_ID IN (SELECT [ID] FROM [dbo].[PRODUCT] WHERE PRODUCT_NAME = '"+ product +"' AND WAREHOUSE_ID IN (SELECT ID FROM WAREHOUSE WHERE WAREHOUSE_NAME = '"+ warehouse +"'))", connection);
            DataTable dataTable = new DataTable();
            adapter.Fill(dataTable);

            try
            {
                //Debug.WriteLine(dataTable.Rows[0][0].ToString()); elemanlara bu şekilde ulaşabilirsin
                if (dataTable.Rows[0] != null)
                {
                    for (int i = 0; i < dataTable.Rows.Count; i++)
                    {
                        lblStock.Text = "The stock of this product is: "+ dataTable.Rows[i][0].ToString();
                        numNewStock.Maximum = (int)dataTable.Rows[i][0];
                    }

                    Calendar.Enabled = true;
                }

            }

            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("There is an error occured while checking the stocks.");
            }
        }

        private void Calendar_DateChanged(object sender, DateRangeEventArgs e)
        {
            comboProduct.Enabled = false;

            numNewStock.Enabled = true;

            buttonRequest.Enabled = true;

        }

        private void numNewStock_ValueChanged(object sender, EventArgs e)
        {
            
        }


        private void buttonRequest_Click(object sender, EventArgs e)
        {
            

            try
            {
                string userName = FormLogin.userName;
                string userSurname = FormLogin.userSurname;
                string userPassword = FormLogin.userPassword;

                string companyName = comboCompany.Text;
                string warehouseName = comboWarehouse.Text;
                string productName = comboProduct.Text;

                int quantity = ((int)numNewStock.Value);

                DateTime orderDate = DateTime.UtcNow.Date;
                DateTime recieveDate = Calendar.SelectionStart.Date;

                string connectionString = "Data Source = DESKTOP-EMM47NV; Initial Catalog = StockControlSystem; Integrated Security = true";
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();

                string sqlCommend = "INSERT INTO [dbo].[OPERATION]" +
                    "([EMPLOYEE_PERFORMING_OPERATION_ID]," +
                    "[CUSTOMER_COMPANY_MAKING_REQUEST_ID]," +
                    "[MANUFACTURER_COMPANY_SENDING_REQUEST_ID]," +
                    "[WAREHOUSE_SENDING_REQUEST_ID]," +
                    "[PRODUCT_ID]," +
                    "[QUANTITY]," +
                    "[ORDER_DATE]," +
                    "[RECIEVE_DATE]," +
                    "[STATU]) VALUES " +
                    "((SELECT ID FROM [dbo].[USER] WHERE USER_NAME ='" + userName + "' AND USER_SURNAME ='" + userSurname + "' AND PASSWORD ='" + userPassword + "')," +
                    "(SELECT COMPANY_ID FROM [dbo].[USER] WHERE USER_NAME ='" + userName + "' AND USER_SURNAME ='" + userSurname + "' AND PASSWORD ='" + userPassword + "')," +
                    "(SELECT ID FROM COMPANY WHERE COMPANY_NAME = '" + companyName + "')," +
                    "(SELECT ID FROM WAREHOUSE WHERE WAREHOUSE_NAME = '" + warehouseName + "')," +
                    "(SELECT ID FROM PRODUCT WHERE PRODUCT_NAME = '" + productName + "' AND WAREHOUSE_ID IN (SELECT ID FROM WAREHOUSE WHERE WAREHOUSE_NAME = '"+ warehouseName + "'))," +
                    quantity + ",'" +
                    orderDate + "','" +
                    recieveDate + "'," +
                    "'On Process')";

                Debug.WriteLine(sqlCommend);

                SqlCommand command = new SqlCommand(sqlCommend, connection);

                int result = 0;

                result = Convert.ToInt32(command.ExecuteNonQuery());

                if (result != 0)
                {
                    System.Windows.Forms.MessageBox.Show("Your request is saved.");

                }
                else
                {
                    System.Windows.Forms.MessageBox.Show("Your request can not saved.");
                }

            }

            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("There is an error occured while saving the request!!!");
            }


        }

        private void buttonReset_Click(object sender, EventArgs e)
        {
            comboCompany.Enabled = true;

            comboCity.Enabled = false;
            comboCity.Items.Clear();
            comboCity.Text = "";

            comboWarehouse.Enabled = false;
            comboWarehouse.Items.Clear();
            comboWarehouse.Text = "";

            comboCategory.Enabled = false;
            comboCategory.Items.Clear();
            comboCategory.Text = "";

            comboProduct.Enabled = false;
            comboProduct.Items.Clear();
            comboProduct.Text = "";

            Calendar.Enabled = false;

            numNewStock.Enabled = false;
            numNewStock.Value = 0;
        }
    }
}
