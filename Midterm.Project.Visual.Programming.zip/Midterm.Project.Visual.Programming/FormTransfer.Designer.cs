﻿namespace Midterm.Project.Visual.Programming
{
    partial class FormTransfer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormTransfer));
            this.labelProduct = new System.Windows.Forms.Label();
            this.lblStock = new System.Windows.Forms.Label();
            this.comboProduct = new System.Windows.Forms.ComboBox();
            this.lblExp1 = new System.Windows.Forms.Label();
            this.buttonUpdate = new System.Windows.Forms.Button();
            this.comboWarehouse = new System.Windows.Forms.ComboBox();
            this.labelWarehouse = new System.Windows.Forms.Label();
            this.lblLogoTransfer = new System.Windows.Forms.Label();
            this.picLogoTransfer = new System.Windows.Forms.PictureBox();
            this.labelNewStock = new System.Windows.Forms.Label();
            this.labelCategory = new System.Windows.Forms.Label();
            this.comboCategory = new System.Windows.Forms.ComboBox();
            this.numNewStock = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.picLogoTransfer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numNewStock)).BeginInit();
            this.SuspendLayout();
            // 
            // labelProduct
            // 
            this.labelProduct.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelProduct.AutoSize = true;
            this.labelProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelProduct.ForeColor = System.Drawing.Color.DarkBlue;
            this.labelProduct.Location = new System.Drawing.Point(548, 212);
            this.labelProduct.Name = "labelProduct";
            this.labelProduct.Size = new System.Drawing.Size(64, 17);
            this.labelProduct.TabIndex = 0;
            this.labelProduct.Text = "Product";
            this.labelProduct.Click += new System.EventHandler(this.labelProduct_Click);
            // 
            // lblStock
            // 
            this.lblStock.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblStock.AutoSize = true;
            this.lblStock.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblStock.Location = new System.Drawing.Point(302, 286);
            this.lblStock.Name = "lblStock";
            this.lblStock.Size = new System.Drawing.Size(211, 17);
            this.lblStock.TabIndex = 0;
            this.lblStock.Text = "The stock of this product is:";
            this.lblStock.Click += new System.EventHandler(this.lblStock_Click);
            // 
            // comboProduct
            // 
            this.comboProduct.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboProduct.Enabled = false;
            this.comboProduct.FormattingEnabled = true;
            this.comboProduct.Location = new System.Drawing.Point(616, 209);
            this.comboProduct.Name = "comboProduct";
            this.comboProduct.Size = new System.Drawing.Size(138, 21);
            this.comboProduct.TabIndex = 3;
            this.comboProduct.SelectedIndexChanged += new System.EventHandler(this.comboProduct_SelectedIndexChanged);
            // 
            // lblExp1
            // 
            this.lblExp1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblExp1.AutoSize = true;
            this.lblExp1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lblExp1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblExp1.Location = new System.Drawing.Point(184, 159);
            this.lblExp1.Name = "lblExp1";
            this.lblExp1.Size = new System.Drawing.Size(428, 17);
            this.lblExp1.TabIndex = 0;
            this.lblExp1.Text = "Please select Warehouse, Category and Product to see the Stocks\r\n";
            this.lblExp1.Click += new System.EventHandler(this.lblExp1_Click);
            // 
            // buttonUpdate
            // 
            this.buttonUpdate.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.buttonUpdate.BackColor = System.Drawing.Color.White;
            this.buttonUpdate.Enabled = false;
            this.buttonUpdate.FlatAppearance.BorderColor = System.Drawing.Color.DarkBlue;
            this.buttonUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.buttonUpdate.ForeColor = System.Drawing.Color.DarkBlue;
            this.buttonUpdate.Location = new System.Drawing.Point(330, 405);
            this.buttonUpdate.Name = "buttonUpdate";
            this.buttonUpdate.Size = new System.Drawing.Size(138, 32);
            this.buttonUpdate.TabIndex = 6;
            this.buttonUpdate.Text = "Update Stocks";
            this.buttonUpdate.UseVisualStyleBackColor = false;
            this.buttonUpdate.Click += new System.EventHandler(this.buttonUpdate_Click);
            // 
            // comboWarehouse
            // 
            this.comboWarehouse.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboWarehouse.FormattingEnabled = true;
            this.comboWarehouse.Location = new System.Drawing.Point(102, 209);
            this.comboWarehouse.Name = "comboWarehouse";
            this.comboWarehouse.Size = new System.Drawing.Size(138, 21);
            this.comboWarehouse.TabIndex = 1;
            this.comboWarehouse.SelectedIndexChanged += new System.EventHandler(this.comboWarehouse_SelectedIndexChanged);
            // 
            // labelWarehouse
            // 
            this.labelWarehouse.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelWarehouse.AutoSize = true;
            this.labelWarehouse.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelWarehouse.ForeColor = System.Drawing.Color.DarkBlue;
            this.labelWarehouse.Location = new System.Drawing.Point(8, 211);
            this.labelWarehouse.Name = "labelWarehouse";
            this.labelWarehouse.Size = new System.Drawing.Size(90, 17);
            this.labelWarehouse.TabIndex = 0;
            this.labelWarehouse.Text = "Warehouse";
            this.labelWarehouse.Click += new System.EventHandler(this.labelWarehouse_Click);
            // 
            // lblLogoTransfer
            // 
            this.lblLogoTransfer.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblLogoTransfer.AutoSize = true;
            this.lblLogoTransfer.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblLogoTransfer.ForeColor = System.Drawing.Color.DarkBlue;
            this.lblLogoTransfer.Location = new System.Drawing.Point(291, 96);
            this.lblLogoTransfer.Name = "lblLogoTransfer";
            this.lblLogoTransfer.Size = new System.Drawing.Size(207, 24);
            this.lblLogoTransfer.TabIndex = 0;
            this.lblLogoTransfer.Text = "Stock Control System";
            this.lblLogoTransfer.Click += new System.EventHandler(this.lblLogoTransfer_Click);
            // 
            // picLogoTransfer
            // 
            this.picLogoTransfer.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.picLogoTransfer.Image = ((System.Drawing.Image)(resources.GetObject("picLogoTransfer.Image")));
            this.picLogoTransfer.Location = new System.Drawing.Point(354, 12);
            this.picLogoTransfer.Name = "picLogoTransfer";
            this.picLogoTransfer.Size = new System.Drawing.Size(89, 81);
            this.picLogoTransfer.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picLogoTransfer.TabIndex = 21;
            this.picLogoTransfer.TabStop = false;
            this.picLogoTransfer.Click += new System.EventHandler(this.picLogoTransfer_Click);
            // 
            // labelNewStock
            // 
            this.labelNewStock.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelNewStock.AutoSize = true;
            this.labelNewStock.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelNewStock.ForeColor = System.Drawing.Color.DarkBlue;
            this.labelNewStock.Location = new System.Drawing.Point(216, 353);
            this.labelNewStock.Name = "labelNewStock";
            this.labelNewStock.Size = new System.Drawing.Size(274, 17);
            this.labelNewStock.TabIndex = 0;
            this.labelNewStock.Text = "Update the Stock for this Product to:";
            this.labelNewStock.Click += new System.EventHandler(this.labelNewStock_Click);
            // 
            // labelCategory
            // 
            this.labelCategory.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.labelCategory.AutoSize = true;
            this.labelCategory.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labelCategory.ForeColor = System.Drawing.Color.DarkBlue;
            this.labelCategory.Location = new System.Drawing.Point(281, 213);
            this.labelCategory.Name = "labelCategory";
            this.labelCategory.Size = new System.Drawing.Size(73, 17);
            this.labelCategory.TabIndex = 0;
            this.labelCategory.Text = "Category";
            // 
            // comboCategory
            // 
            this.comboCategory.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboCategory.Enabled = false;
            this.comboCategory.FormattingEnabled = true;
            this.comboCategory.Location = new System.Drawing.Point(360, 210);
            this.comboCategory.Name = "comboCategory";
            this.comboCategory.Size = new System.Drawing.Size(138, 21);
            this.comboCategory.TabIndex = 2;
            this.comboCategory.SelectedIndexChanged += new System.EventHandler(this.comboCategory_SelectedIndexChanged);
            // 
            // numNewStock
            // 
            this.numNewStock.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.numNewStock.Enabled = false;
            this.numNewStock.Location = new System.Drawing.Point(496, 353);
            this.numNewStock.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.numNewStock.Name = "numNewStock";
            this.numNewStock.Size = new System.Drawing.Size(81, 20);
            this.numNewStock.TabIndex = 5;
            this.numNewStock.ValueChanged += new System.EventHandler(this.numNewStock_ValueChanged);
            // 
            // FormTransfer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.numNewStock);
            this.Controls.Add(this.labelCategory);
            this.Controls.Add(this.comboCategory);
            this.Controls.Add(this.labelNewStock);
            this.Controls.Add(this.labelProduct);
            this.Controls.Add(this.lblStock);
            this.Controls.Add(this.comboProduct);
            this.Controls.Add(this.lblExp1);
            this.Controls.Add(this.buttonUpdate);
            this.Controls.Add(this.comboWarehouse);
            this.Controls.Add(this.labelWarehouse);
            this.Controls.Add(this.lblLogoTransfer);
            this.Controls.Add(this.picLogoTransfer);
            this.Name = "FormTransfer";
            this.Text = "Stock Control System - Warehouse & Inventory Transfer";
            this.Load += new System.EventHandler(this.FormTransfer_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picLogoTransfer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numNewStock)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label labelProduct;
        private System.Windows.Forms.Label lblStock;
        private System.Windows.Forms.ComboBox comboProduct;
        private System.Windows.Forms.Label lblExp1;
        private System.Windows.Forms.Button buttonUpdate;
        private System.Windows.Forms.ComboBox comboWarehouse;
        private System.Windows.Forms.Label labelWarehouse;
        private System.Windows.Forms.Label lblLogoTransfer;
        private System.Windows.Forms.PictureBox picLogoTransfer;
        private System.Windows.Forms.Label labelNewStock;
        private System.Windows.Forms.Label labelCategory;
        private System.Windows.Forms.ComboBox comboCategory;
        private System.Windows.Forms.NumericUpDown numNewStock;
    }
}