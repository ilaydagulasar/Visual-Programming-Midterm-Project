﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Midterm.Project.Visual.Programming
{
    public partial class FormTransfer : Form
    {
        public FormTransfer()
        {
            InitializeComponent();
        }

        private void FormTransfer_Load(object sender, EventArgs e)
        {
            comboWarehouse.Enabled = true;

            string company = "";

            string connectionString = "Data Source = DESKTOP-EMM47NV; Initial Catalog = StockControlSystem; Integrated Security = true";
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();

            string userName = FormLogin.userName;
            string userSurname = FormLogin.userSurname;
            string userPassword = FormLogin.userPassword;

            SqlDataAdapter adapter = new SqlDataAdapter("SELECT WAREHOUSE_NAME FROM WAREHOUSE WHERE COMPANY_ID IN (SELECT [COMPANY_ID] FROM [dbo].[USER] WHERE USER_NAME='" + userName +"' AND USER_SURNAME='"+ userSurname +"' AND PASSWORD='"+ userPassword +"')", connection);
            DataTable dataTable = new DataTable();
            adapter.Fill(dataTable);

            comboWarehouse.Items.Clear();

            try
            {
                //Debug.WriteLine(dataTable.Rows[0][0].ToString()); elemanlara bu şekilde ulaşabilirsin
                if (dataTable.Rows[0] != null)
                {
                    for (int i = 0; i < dataTable.Rows.Count; i++)
                    {
                        comboWarehouse.Items.Add(dataTable.Rows[i][0]);
                    }
                }

            }

            catch (Exception ex)
            {
                //error mesajı ver
            }
        }


        private void picLogoTransfer_Click(object sender, EventArgs e)
        {

        }

        private void lblLogoTransfer_Click(object sender, EventArgs e)
        {

        }

        private void lblExp1_Click(object sender, EventArgs e)
        {

        }

        private void labelCity_Click(object sender, EventArgs e)
        {

        }

        private void labelWarehouse_Click(object sender, EventArgs e)
        {

        }

        private void labelProduct_Click(object sender, EventArgs e)
        {

        }

        private void comboCity_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboWarehouse_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboCategory.Enabled = true;

            string warehouse = comboWarehouse.SelectedItem.ToString();

            string connectionString = "Data Source = DESKTOP-EMM47NV; Initial Catalog = StockControlSystem; Integrated Security = true";
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();

            SqlDataAdapter adapter = new SqlDataAdapter("SELECT [ID],[PRODUCT_NAME],[CATEGORY],[PRODUCT_CODE],[WAREHOUSE_ID] FROM [dbo].[PRODUCT] WHERE WAREHOUSE_ID IN (SELECT ID FROM WAREHOUSE WHERE WAREHOUSE_NAME = '" + warehouse + "')", connection);
            DataTable dataTable = new DataTable();
            adapter.Fill(dataTable);

            comboCategory.Items.Clear();

            string categories = "";

            try
            {
                //Debug.WriteLine(dataTable.Rows[0][0].ToString()); elemanlara bu şekilde ulaşabilirsin
                if (dataTable.Rows[0] != null)
                {
                    for (int i = 0; i < dataTable.Rows.Count; i++)
                    {

                        if (categories != dataTable.Rows[i][2].ToString().Trim())
                        {
                            categories = dataTable.Rows[i][2].ToString().Trim();
                            comboCategory.Items.Add(dataTable.Rows[i][2]);
                        }

                    }
                }

            }

            catch (Exception ex)
            {
                //error mesajı ver
            }
        }

        private void comboProduct_SelectedIndexChanged(object sender, EventArgs e)
        {
            string product = comboProduct.SelectedItem.ToString();
            string warehouse = comboWarehouse.SelectedItem.ToString();

            string connectionString = "Data Source = DESKTOP-EMM47NV; Initial Catalog = StockControlSystem; Integrated Security = true";
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();

            SqlDataAdapter adapter = new SqlDataAdapter("SELECT STOCK_QUANTITY FROM STOCK WHERE PRODUCT_ID IN (SELECT [ID] FROM [dbo].[PRODUCT] WHERE PRODUCT_NAME = '" + product + "' AND WAREHOUSE_ID IN (SELECT ID FROM WAREHOUSE WHERE WAREHOUSE_NAME = '" + warehouse + "'))", connection);
            DataTable dataTable = new DataTable();
            adapter.Fill(dataTable);

            try
            {
                //Debug.WriteLine(dataTable.Rows[0][0].ToString()); elemanlara bu şekilde ulaşabilirsin
                if (dataTable.Rows[0] != null)
                {
                    for (int i = 0; i < dataTable.Rows.Count; i++)
                    {
                        lblStock.Text = "The stock of this product is: " + dataTable.Rows[i][0].ToString();
                        numNewStock.Value = (int)dataTable.Rows[i][0];
                    }

                    numNewStock.Enabled = true;
                }

            }

            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("There is an error occured while checking the stocks.");
            }
        }

        private void lblStock_Click(object sender, EventArgs e)
        {
            
        }

        private void labelNewStock_Click(object sender, EventArgs e)
        {

        }

        private void txtNewStock_TextChanged(object sender, EventArgs e)
        {

        }

        private void buttonUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                string warehouseName = comboWarehouse.Text;
                string categoryName = comboCategory.Text;
                string productName = comboProduct.Text;
                int quantity = ((int)numNewStock.Value);
                
                string connectionString = "Data Source = DESKTOP-EMM47NV; Initial Catalog = StockControlSystem; Integrated Security = true";
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();

                string sqlCommend = "UPDATE [dbo].[STOCK] SET [STOCK_QUANTITY] = "+ quantity + " WHERE PRODUCT_ID IN (SELECT [ID] FROM [dbo].[PRODUCT] WHERE [PRODUCT_NAME] = '"+ productName + "' AND [CATEGORY] = '"+ categoryName + "' AND [WAREHOUSE_ID] IN (SELECT ID FROM WAREHOUSE WHERE WAREHOUSE_NAME = '"+ warehouseName + "') )";

                SqlCommand command = new SqlCommand(sqlCommend, connection);

                int result = 0;

                result = Convert.ToInt32(command.ExecuteNonQuery());

                if (result != 0)
                {
                    System.Windows.Forms.MessageBox.Show("Your stock is updated.");
                    
                }
                else
                {
                    System.Windows.Forms.MessageBox.Show("Your stock is not updated.");
                }


            }

            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("There is an error occured while saving the request!!!");
            }
        }

        private void comboCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboProduct.Enabled = true;

            string warehouse = comboWarehouse.SelectedItem.ToString();
            string category = comboCategory.SelectedItem.ToString();

            string connectionString = "Data Source = DESKTOP-EMM47NV; Initial Catalog = StockControlSystem; Integrated Security = true";
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();

            SqlDataAdapter adapter = new SqlDataAdapter("SELECT [ID],[PRODUCT_NAME],[CATEGORY],[PRODUCT_CODE],[WAREHOUSE_ID] FROM [dbo].[PRODUCT] WHERE WAREHOUSE_ID IN (SELECT ID FROM WAREHOUSE WHERE WAREHOUSE_NAME = '" + warehouse + "') AND CATEGORY = '" + category + "'", connection);
            DataTable dataTable = new DataTable();
            adapter.Fill(dataTable);

            comboProduct.Items.Clear();

            try
            {
                //Debug.WriteLine(dataTable.Rows[0][0].ToString()); elemanlara bu şekilde ulaşabilirsin
                if (dataTable.Rows[0] != null)
                {
                    for (int i = 0; i < dataTable.Rows.Count; i++)
                    {
                        comboProduct.Items.Add(dataTable.Rows[i][1]);
                    }
                }

            }

            catch (Exception ex)
            {
                //error mesajı ver
            }
        }

        private void numNewStock_ValueChanged(object sender, EventArgs e)
        {

            buttonUpdate.Enabled = true;

            int requestNumber = ((int)numNewStock.Value);
        }
    }
}
